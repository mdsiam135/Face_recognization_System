import cv2
print(cv2.__version__)
clf = cv2.face.LBPHFaceRecognizer_create()
print("LBPHFaceRecognizer is available!")
